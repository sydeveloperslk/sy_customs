// const express = require("express");
// const {createServer, Server} =require("http");
// const { server } = require("socket.io");
// const app =express();
// const httpServer=createServer(app)
// const io= new Server(httpServer); 

// app.route("/").get((req,res)=>{
//     res.json("Hey there welcomes");
// })
// io.on("connection",(Socket)=>{
//     console.log("Connected");
// });
// httpServer.listen(5001);
const express = require("express");
const http = require("http");
const https = require("https");
const fs = require("fs");
const app = express();
const port = process.env.PORT || 5001;

// Create an HTTPS server with your SSL certificate and private key
const privateKey = fs.readFileSync("key.pem", "utf8");
const certificate = fs.readFileSync("certi.pem", "utf8");
const credentials = { key: privateKey, cert: certificate };
const httpsServer = https.createServer(credentials, app);
     
// Creat e an HTTP server (optional)
const httpServer = http.createServer(app);
// Middleware
app.use(express.json());

var clients = {};

// Socket.IO connection on the HTTPS server
const io = require("socket.io")(httpsServer);

io.on("connection", (socket) => {
  console.log("connected");
  console.log(socket.id, "has joined");

  socket.on("signin", (id) => {
    console.log(id);
    clients[id] = socket;
    console.log(clients);
  });

  socket.on("message", (msg) => {
    console.log(msg);
    let targetId = msg.targetId;
    if (clients[targetId]) clients[targetId].emit("message", msg);
  });
});

// Start both HTTP and HTTPS servers
httpServer.listen(5000, "0.0.0.0", () => {
  console.log("HTTP server started on port 5000");
});

httpsServer.listen(port, "0.0.0.0", () => {
  console.log("HTTPS server started on port", port);
});

// var server = require("ws").Server;
// var s = new server({ port: 5001 });

// s.on('connection', function (ws) {
//     ws.on('message', function (event) {
//         var json = JSON.parse(event);
//         switch (json.type) {
//             case 'name':
//                 ws.personName = json.data;
//                 s.clients.forEach(function (client) {
//                     // if (client != ws) {
//                         client.send(JSON.stringify({
//                             type: "name",
//                             data: ws.personName,
//                         }));
//                     // }
//                 });
//                 break;
//             case 'message':
//                 s.clients.forEach(function (client) {
//                     // if (client != ws) {
//                         client.send(JSON.stringify({
//                             type: "message",
//                             name: ws.personName,
//                             data: json.data
//                         }));
//                     // }
//                 });
//                 break;
//         }
//         // ws.send(event.toString());
//     });

//     console.log('Once more client connection');
    
//     ws.on('close', function () {
//         console.log("I have lost a client");
//     });
// });
